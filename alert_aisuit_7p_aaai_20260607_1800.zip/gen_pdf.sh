#!/usr/bin/env bash
set -euo pipefail

# Generate main.pdf from main.tex on Ubuntu.
# Usage:
#   ./gen_pdf.sh
#
# Required packages:
#   sudo apt-get update
#   sudo apt-get install -y latexmk texlive-latex-recommended texlive-latex-extra texlive-fonts-recommended texlive-base texlive-binaries texlive-bibtex-extra

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

MAIN_TEX="main.tex"
MAIN_PDF="main.pdf"

if ! command -v latexmk >/dev/null 2>&1; then
  echo "ERROR: latexmk is not installed."
  echo "Install it on Ubuntu with:"
  echo "  sudo apt-get update"
  echo "  sudo apt-get install -y latexmk texlive-latex-recommended texlive-latex-extra texlive-fonts-recommended texlive-base texlive-binaries texlive-base texlive-binaries texlive-bibtex-extra"
  exit 1
fi


if [[ ! -f "$MAIN_TEX" ]]; then
  echo "ERROR: $MAIN_TEX not found in $SCRIPT_DIR"
  exit 1
fi

# Clean old auxiliary files but keep source files and existing PDFs safe.
# If BibTeX is unavailable, keep the checked-in main.bbl and run pdflatex only.
if command -v bibtex >/dev/null 2>&1; then
  latexmk -C "$MAIN_TEX" >/dev/null 2>&1 || true
  latexmk -pdf -interaction=nonstopmode -file-line-error "$MAIN_TEX"
else
  echo "WARNING: bibtex not found; using checked-in main.bbl with pdfLaTeX fallback."
  pdflatex -interaction=nonstopmode -file-line-error "$MAIN_TEX"
  pdflatex -interaction=nonstopmode -file-line-error "$MAIN_TEX"
fi

if [[ -f "$MAIN_PDF" ]]; then
  echo "SUCCESS: generated $SCRIPT_DIR/$MAIN_PDF"
else
  echo "ERROR: PDF generation finished but $MAIN_PDF was not found."
  exit 1
fi
