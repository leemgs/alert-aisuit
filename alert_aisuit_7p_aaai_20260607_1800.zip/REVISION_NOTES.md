# Revision notes for AAAI reviewer-aligned version

Updated based on review-risk comments:

- Sharpened novelty: reframed ALERT around the retrieval-time point-in-time authority gate, not generic legal monitoring, RAG, citators, CSVs, or agents.
- Elevated human-adjudicated evaluation: human-only subset is now the primary validity/circularity check; full held-out results are presented as scale/comparability results.
- Strengthened annotation protocol description: added fixed guideline, blinded final adjudication, and disagreement handling.
- Repositioned temporal-gating ablation as the main mechanism result and added a qualitative failure-mode explanation for flat retrieval.
- Reduced emphasis on operational plumbing/free-tier implementation in the main text and moved it conceptually to appendix details.
- Tightened Discussion/Conclusion to keep claims bounded: no legal advice, no outcome prediction, no correctness under temporal shift.
- Kept P1/P2 external-stack transfer/citator agreement as pre-registered protocols rather than fabricated results, because no new external experiment outputs were provided.

Compilation note:
- `pdflatex main.tex` was run twice using the existing `main.bbl` because `bibtex` is not installed in the execution environment.
- The generated `main.pdf` has 15 pages total; Conclusion appears on page 7 and References begin on page 8, satisfying the stated main-content page target.


## revised8 update
- Strengthened self-verifying mechanism: Goal Checker now emits structured residual critiques that drive query reformulation rather than simple retries.
- Clarified PLRE difficulty as an engineering-language-to-legal-theory domain gap under point-in-time authority.
- Hardened circularity defense: primary significance claims are human-adjudicated only; retained labels are scale-oriented comparisons.
- Added explicit human-in-the-loop mitigation for low-confidence negative treatment edges and made unresolved validity a reportable state.
- Added main-text backbone robustness note referencing the open-weights rerun while avoiding unsupported claims of prompt invariance.


## 2026-06-06 Reviewer-risk revision by ChatGPT

This revision reflects AAAI-style reviewer-risk feedback without fabricating new experimental results.

Main changes:
- Re-centered the novelty claim around the retrieval-time point-in-time authority gate rather than the agentic pipeline.
- Added an explicit “not just legal RAG / not just monitoring” paragraph in the Introduction.
- Tightened operational CourtListener/CSV/GitHub/Slack prose to make room for methodological clarification.
- Clarified PLRE gold-label construction: product-attribute cards, theory cards, query dates, valid supporting authority, and stale-authority distractors.
- Reworded PLRE baselines to reduce ambiguity around “style” baselines and emphasize what each baseline controls.
- Strengthened RQ3 interpretation: the gate changes evidence before generation, not citation filtering after generation.
- Updated Discussion and Conclusion to present P1/P2 as future validation protocols, not executed results.

Important limitation:
- No new P1/P2 external-stack or authoritative-citator results were invented. For a stronger AAAI submission, run at least P1 or P2 and replace the protocol-only language with measured results.


## Final revision for additional AAAI reviewer-risk feedback

This revision incorporates the latest reviewer-risk feedback while preserving the 7-page technical-body target:

- Reframed PLRE as directional, context-aware entailment with an exogenous time-indexed support constraint.
- Reduced operational workflow emphasis in the problem formulation and system overview.
- Recast Proposition 1 as coverage-controlled stopping with escalation and made conformal evidence-omission control explicit.
- Strengthened the algorithmic interpretation of Eq. (3) as a constrained retrieval operator, distinct from soft temporal reranking and post-hoc citator warnings.
- Added a discussion paragraph explaining how the self-verifying/critique loop localizes treatment-edge uncertainty and justifies system complexity.
- Clarified that P1/P2 remain protocols/future validation unless actually executed, avoiding unsupported claims.

## 2026-06-07 Reviewer-comment revision (writing/framing only; no fabricated results)

Implemented the editable subset of the AAAI reviewer-risk feedback. NO new
experimental numbers were invented; P1 (external-stack transfer) and P2
(authoritative-citator agreement) remain pre-registered protocols, because
fabricating those results would be research misconduct. Running at least one of
them is still the single highest-value step before submission.

Changes made (all length-neutral; 7-page technical body preserved — Conclusion
ends on page 7, References begin on page 8):
- Novelty/generality: reframed the gate (Eq. 3) as a domain-general
  validity-interval operator (any time-stamped, supersession-bearing authority
  corpus), instantiated for law — raising the reusable-contribution framing
  (Intro + Discussion).
- w(.) specification: replaced the vague description with an explicit bounded
  monotone schedule in (0,1] (exact schedule released with implementation).
- PLRE circularity defense: clarified that gold-label validity is judged by
  annotators reading docket/opinion text independently of ALERT's auto-extracted
  treatment graph, so the gate must recover (not presuppose) label validity;
  extractor-independent re-check tied to P2's downstream link.
- Effect-size honesty (RQ1): noted that marginal CIs overlap but the paired
  bootstrap removes between-case variance; the gap over B5 is read as modest.
- Temporal-shift honesty (Discussion): stated that the omission guarantee is
  weakest under the temporal split (non-stationary litigation) and made
  rolling/weighted re-calibration a deployment requirement.
- Made P1/P2 the explicit "decisive next step" rather than settled results.
- Space recovered by trimming redundant plumbing/scope prose duplicated across
  abstract, intro, appendix (scoring-matrix detail, signposting, retriever
  detail, Open-Source subsection heading, attorney-field detail).

Still REQUIRED for a strong submission (cannot be done by editing — needs real
experiments): run P2 on a stratified sample (>=150 negative-treatment edges)
against KeyCite/Shepard's; run P1 on >=1 host retriever + the temporally
held-out CourtListener slice; and an extractor-independent PLRE label audit.

Toolchain note: built with pdflatex + bibtex (full cycle) in this environment;
main.pdf = 15 pages, body (through Conclusion) = 7 pages.
Reminder: swap aaai2026.sty/.bst for the official AAAI-27 author-kit files
before final upload, and check that distinctive identifiers (ai-suit-tracker,
ai-suit-sensing.csv) do not de-anonymize via a public repo.

## 2026-06-07 Reviewer-comment revision (Claude) — writing/format only; NO fabricated results

Applied ONLY the editable subset of AAAI reviewer-risk feedback. No experimental
numbers were added or altered. P1 (external-stack transfer) and P2
(authoritative-citator agreement) remain pre-registered protocols — fabricating
those results would be research misconduct. Running at least one of them is still
the single highest-value, accept/reject-determining step before submission, and
this edit pass does NOT change that.

Concrete edits (length-controlled; 7-page technical body preserved — Conclusion
ends on p.7, References begin on p.8; total 15 pages):
- 045_motivation.tex: operationalized the previously undefined Quality(R,D,P)
  objective in Eq.(1) — each of its four components is now tied to a measured RQ
  (severity-label F1/RQ1, blinded report ratings/RQ2, coverage loss L_tau/RQ6),
  and Eq.(1) is framed as a conceptual objective, not a directly optimized loss.
  Tightened the redundant operational-scoping sentence to offset added length.
- 065_evaluation.tex (RQ2): added an honest caveat that the report-quality study
  uses two raters, so RQ2 is treated as supporting (not primary) evidence.

Verified in this environment: full latexmk + bibtex cycle compiles cleanly;
main.pdf rebuilt; alert_aisuit_sensing_20260606_final.pdf synced to the rebuilt
main.pdf so both PDFs in the package are internally consistent.

STILL REQUIRED before a competitive submission (cannot be done by editing):
  1. Run P2 on a stratified sample (>=150 negative-treatment edges) vs
     KeyCite/Shepard's; report negative-treatment micro-F1 and missed-closure rate.
  2. Run P1 on >=1 host retriever + the temporally held-out CourtListener slice;
     report gated-minus-ungated nDCG@10 and stale-cite deltas.
  3. Confirm with the official AAAI-27 author kit (aaai.org/authorkit27) whether
     the Technical Appendix may stay appended to the submission PDF or must be
     uploaded as separate supplementary material.
  4. Replace aaai2026.sty/.bst with the official AAAI-27 kit files before upload.
  5. De-anonymization check: distinctive identifiers (ai-suit-tracker,
     ai-suit-sensing.csv) must not point to a public repo that reveals authorship.

## 2026-06-07 P2 executed — protocol replaced with measured citator-agreement results

Author-supplied KeyCite/Shepard's-style citator-agreement results were integrated;
P2 is no longer protocol-only. NO numbers were invented by the assistant — all
values below were provided by the author.

Changes:
- 088_appendix.tex: protocols intro no longer says "No results are reported";
  it now states P1 is protocol-only (not yet executed) and P2 is executed with
  results in App. P2. Added "Measured P2 results" paragraph plus two result
  tables: Table A.12 (edge agreement) and Table A.13 (closure agreement and
  downstream decision impact). Note: existing Table A.4 (negative-treatment micro
  P/R/F1 = 0.84/0.77/0.80) is the internal hand-labeled GOLD-SPAN validation and
  is intentionally kept distinct from the new external CITATOR validation
  (Table A.12, micro = 0.83/0.80/0.81).
- 075_discussion.tex: replaced "pre-registered but not executed" with measured
  P2 outcome; P1 left as the remaining external-stack transfer validation.
- 085_conclusion.tex: open problems now reference the measured citator-agreement
  level rather than listing P2 as open.

P2 values added (author-provided): negative-treatment micro P/R/F1 = 0.83/0.80/0.81;
missed-closure rate = 20.4%; false-closure rate = 4.8%; closure-date median/mean/P90
error = 18/31/74 days; point-in-time validity accuracy = 0.88; PLRE decision-flip
rate after citator correction = 3.8%; crosswalk IAA kappa = 0.78; n=400 (162 negative).
P2 acceptance criterion (micro-F1 >= 0.80, missed-closure <= 23%) is satisfied.

Verified: full latexmk+bibtex cycle compiles cleanly, no unresolved refs/citations;
main.pdf = 16 pages; technical body still ends at p.7 (Conclusion), References p.8;
P2 tables render on pp.15-16. final-named PDF synced to main.pdf.

Still open (genuinely): P1 external-stack transfer is the remaining unexecuted
validation; AAAI-27 kit swap (aaai2026 -> aaai2027 .sty/.bst); confirm appendix
may stay in submission PDF vs separate supplementary; de-anonymization check on
ai-suit-tracker / ai-suit-sensing.csv identifiers.
